module.exports = {
  extends: ['stylelint-config-tailwindcss'],
  rules: {
    // You can add extra rules if you want
    'at-rule-no-unknown': null,
  },
};
